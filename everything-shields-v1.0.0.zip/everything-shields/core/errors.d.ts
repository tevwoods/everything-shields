export declare class ShieldError extends Error {
    constructor(message: string);
}
export declare class RuneError extends Error {
    constructor(message: string);
}
export declare function handleError(error: Error): void;
