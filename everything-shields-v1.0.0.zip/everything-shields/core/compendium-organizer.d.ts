declare global {
    interface Collection<T> {
        find(predicate: (item: T) => boolean): T | undefined;
        filter(predicate: (item: T) => boolean): T[];
    }
    interface Game {
        folders: Collection<Folder>;
        packs: Collection<CompendiumPack>;
    }
    interface CompendiumPack {
        metadata: {
            packageName: string;
        };
        folder?: {
            id: string;
        };
        setFolder(folderId: string): Promise<void>;
    }
    interface Folder {
        id: string;
        type: string;
        name: string;
    }
    namespace globalThis {
        var Folder: {
            create(data: {
                name: string;
                type: string;
                parent: string | null;
                color?: string;
            }): Promise<Folder>;
        };
    }
}
export declare function organizeCompendiums(): Promise<void>;
