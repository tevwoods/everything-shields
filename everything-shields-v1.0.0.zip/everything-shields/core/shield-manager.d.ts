import { Shield, RuneRemovalOptions } from '../types/shield';
export declare class ShieldManager {
    private static instance;
    private settings;
    private effectManager;
    private constructor();
    static getInstance(): ShieldManager;
    private getShieldAndParent;
    removePropertyRune(options: RuneRemovalOptions): Promise<void>;
    removePotencyRune(options: RuneRemovalOptions): Promise<void>;
    removeHardenedRune(options: RuneRemovalOptions): Promise<void>;
    applyDamage(shield: Shield, damage: number): Promise<void>;
    repair(shield: Shield, amount: number): Promise<void>;
    addRune(shield: Shield, runeType: string, value: number): Promise<void>;
    updateShieldName(shield: Shield): Promise<void>;
    /**
     * Get property rune description from compendium
     */
    private getPropertyRuneDescription;
    /**
     * Remove all property rune sections from description
     */
    private removePropertyRuneSections;
    /**
     * Update table values in shield description (HP, Hardness, BT)
     */
    private updateShieldTableValues;
    /**
     * Replace a value in the shield table
     */
    private replaceTableValue;
    updateShieldDescription(shield: Shield): Promise<void>;
    /**
     * Recalculate and apply all derived shield stats (price, HP, hardness, description, name)
     */
    recalcShield(shield: Shield): Promise<void>;
}
