import { Actor, ActorSheet, DragData, Item, UpdateData } from '../types/foundry-types';
export declare class EventHandlerManager {
    private static instance;
    private shieldManager;
    private settings;
    private boundHandleClick;
    private pendingRuneDrops;
    private isShowingRuneDialog;
    private constructor();
    static getInstance(): EventHandlerManager;
    initialize(): void;
    cleanup(): void;
    private registerEventListeners;
    private removeEventListeners;
    private handleClick;
    handleUpdateItem(item: Item, changes: UpdateData, options?: any): Promise<void>;
    private isEverythingShieldsRuneDrop;
    private isCompendiumRuneDrop;
    private isFundamentalRune;
    private getShieldCategory;
    private calculatePotencyHPMultiplier;
    private calculateHardenedBonus;
    private getMaterialHPModifier;
    private getMaterialHardnessModifier;
    private handleMaterialChange;
    private applyPotencyRuneEffect;
    private applyHardenedRuneEffect;
    private applyInvestedTrait;
    private markAsSpecificMagicShield;
    private preserveInitialValues;
    private storeBaseShieldName;
    private getRunePrice;
    private getRuneLevel;
    private updatePriceAndLevel;
    /**
     * Display a dialog allowing the user to select a shield to apply the rune to.
     * If the user confirms application, the rune is added to the chosen shield and, if it originated
     * from the actor's inventory (sourceRuneItemId provided), that rune item is deleted so it does not remain.
     * If the user cancels the dialog, we create the rune item in inventory since we prevented its default creation.
     *
     * @param actor The actor receiving the rune application.
     * @param runeName The name of the rune being applied.
     * @param isFundamental Whether the rune is a fundamental rune (potency/hardened) vs property.
     * @param sourceRuneItemId Optional: the id of the rune item in the actor's inventory. Presence triggers deletion on success.
     * @param runeData The complete rune data from compendium, used to create the item if user cancels.
     */
    private promptShieldSelectionAndApplyRune;
    private handleCompendiumRuneDrop;
    handleDropActorSheetData(actor: Actor, sheet: ActorSheet, dragData: DragData): boolean;
    handleBeforeItemCreation(item: Item, data: UpdateData): Promise<boolean>;
    /**
     * Determine whether the provided Item-like object represents a shield in PF2e.
     */
    private isShieldItem;
}
