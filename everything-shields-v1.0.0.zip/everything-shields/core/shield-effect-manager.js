export class ShieldEffectManager {
    constructor() { }
    static getInstance() {
        if (!ShieldEffectManager.instance) {
            ShieldEffectManager.instance = new ShieldEffectManager();
        }
        return ShieldEffectManager.instance;
    }
    async applyRuneEffect(shield, runeType, value) {
        const effect = {
            id: `${shield.id}-${runeType}-${Date.now()}`,
            label: `Shield ${runeType.charAt(0).toUpperCase() + runeType.slice(1)} Rune`,
            icon: 'systems/pf2e/icons/effects/rune.webp',
            duration: {},
            changes: []
        };
        switch (runeType) {
            case 'reinforcing':
                effect.changes = [
                    {
                        key: 'system.hardness',
                        mode: 2,
                        value: value * 2 // Reinforcing adds 2 hardness per level
                    },
                    {
                        key: 'system.hp.max',
                        mode: 2,
                        value: value * 20 // Reinforcing adds 20 HP per level
                    }
                ];
                break;
            case 'potency':
                effect.changes = [
                    {
                        key: 'system.runes.potency',
                        mode: 5,
                        value: value
                    }
                ];
                break;
            case 'hardened':
                effect.changes = [
                    {
                        key: 'system.hardness',
                        mode: 2,
                        value: value * 2 // Hardened adds 2 hardness per level
                    }
                ];
                break;
        }
        await this.addEffect(shield, effect);
    }
    async addEffect(shield, effect) {
        // Use Foundry's effect system to apply the effect
        await shield.createEmbeddedDocuments('ActiveEffect', [effect]);
    }
    async removeEffect(shield, effectId) {
        await shield.deleteEmbeddedDocuments('ActiveEffect', [effectId]);
    }
    async applyDamage(shield, damage) {
        const currentHp = shield.system.hp.value;
        const newHp = Math.max(0, currentHp - damage);
        const effect = {
            id: `${shield.id}-damage-${Date.now()}`,
            label: 'Shield Damage',
            icon: 'systems/pf2e/icons/effects/damaged.webp',
            duration: {},
            changes: [
                {
                    key: 'system.hp.value',
                    mode: 5,
                    value: newHp
                }
            ]
        };
        await this.addEffect(shield, effect);
        // Check for broken threshold
        if (newHp <= shield.system.hp.brokenThreshold) {
            await this.applyBrokenEffect(shield);
        }
    }
    async applyBrokenEffect(shield) {
        const effect = {
            id: `${shield.id}-broken`,
            label: 'Shield Broken',
            icon: 'systems/pf2e/icons/effects/broken.webp',
            duration: {},
            changes: [
                {
                    key: 'system.traits.value',
                    mode: 0,
                    value: 'broken'
                }
            ]
        };
        await this.addEffect(shield, effect);
    }
    async repair(shield, amount) {
        const currentHp = shield.system.hp.value;
        const maxHp = shield.system.hp.max;
        const newHp = Math.min(maxHp, currentHp + amount);
        const effect = {
            id: `${shield.id}-repair-${Date.now()}`,
            label: 'Shield Repair',
            icon: 'systems/pf2e/icons/effects/repaired.webp',
            duration: {},
            changes: [
                {
                    key: 'system.hp.value',
                    mode: 5,
                    value: newHp
                }
            ]
        };
        await this.addEffect(shield, effect);
        // Remove broken effect if HP is above broken threshold
        if (newHp > shield.system.hp.brokenThreshold) {
            const brokenEffect = shield.effects?.find(e => e.id === `${shield.id}-broken`);
            if (brokenEffect) {
                await this.removeEffect(shield, brokenEffect.id);
            }
        }
    }
}
//# sourceMappingURL=shield-effect-manager.js.map