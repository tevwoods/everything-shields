export declare class UpdateGuard {
    private static updating;
    static isUpdating(id: string): boolean;
    static markStart(id: string): void;
    static markEnd(id: string): void;
    static runExclusive<T>(id: string, fn: () => Promise<T>): Promise<T>;
}
