export interface ModuleSettingsConfig {
    shouldGenerateShieldNames: boolean;
    shouldCalculateShieldPrices: boolean;
    disableAllAutomations: boolean;
    shouldApplyRecommendedChangesToSpecificShields: boolean;
    shouldGenerateShieldDescriptions: boolean;
    useReinforcingRuneInsteadOfPotencyAndHardened: boolean;
}
export declare class SettingsManager {
    private static instance;
    private readonly MODULE_NAME;
    private constructor();
    static getInstance(): SettingsManager;
    init(): void;
    private registerSettings;
    getSetting<T>(key: string): T;
    setSetting<T>(key: string, value: T): Promise<void>;
    getConfig(): ModuleSettingsConfig;
}
