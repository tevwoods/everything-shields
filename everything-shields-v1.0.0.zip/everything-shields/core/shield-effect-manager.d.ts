import { Shield } from '../types/shield';
export interface ShieldEffect {
    id: string;
    label: string;
    icon: string;
    duration: {
        rounds?: number;
        seconds?: number;
        turns?: number;
        startTime?: number;
        startRound?: number;
        startTurn?: number;
    };
    changes: EffectChange[];
}
export interface EffectChange {
    key: string;
    mode: 0 | 1 | 2 | 3 | 4 | 5;
    value: string | number;
    priority?: number;
}
export declare class ShieldEffectManager {
    private static instance;
    private constructor();
    static getInstance(): ShieldEffectManager;
    applyRuneEffect(shield: Shield, runeType: string, value: number): Promise<void>;
    private addEffect;
    removeEffect(shield: Shield, effectId: string): Promise<void>;
    applyDamage(shield: Shield, damage: number): Promise<void>;
    applyBrokenEffect(shield: Shield): Promise<void>;
    repair(shield: Shield, amount: number): Promise<void>;
}
