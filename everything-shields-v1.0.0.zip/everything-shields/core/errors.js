export class ShieldError extends Error {
    constructor(message) {
        super(message);
        this.name = 'ShieldError';
    }
}
export class RuneError extends Error {
    constructor(message) {
        super(message);
        this.name = 'RuneError';
    }
}
export function handleError(error) {
    console.error(`[Everything Shields] ${error.name}: ${error.message}`);
    ui?.notifications?.error(`Everything Shields: ${error.message}`);
}
//# sourceMappingURL=errors.js.map