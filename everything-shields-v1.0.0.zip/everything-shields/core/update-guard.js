export class UpdateGuard {
    static isUpdating(id) {
        return UpdateGuard.updating.has(id);
    }
    static markStart(id) {
        UpdateGuard.updating.add(id);
    }
    static markEnd(id) {
        UpdateGuard.updating.delete(id);
    }
    static async runExclusive(id, fn) {
        if (UpdateGuard.isUpdating(id)) {
            // Already updating; just run but do not re-mark
            return fn();
        }
        UpdateGuard.markStart(id);
        try {
            return await fn();
        }
        finally {
            UpdateGuard.markEnd(id);
        }
    }
}
UpdateGuard.updating = new Set();
//# sourceMappingURL=update-guard.js.map