import { Shield } from '../types/shield';
export interface ShieldCalculations {
    name?: string;
    description?: string;
    price?: number;
    hpMax?: number;
    hpValue?: number | null;
    hardness?: number;
    traits?: string[];
}
/**
 * Calculate shield derived values (HP, hardness, price, description, name).
 * This function is used primarily for name and description generation.
 * HP and hardness calculations are handled in event-handler-manager.ts
 */
export declare function calculateShieldUpdates(shield: Shield): ShieldCalculations;
